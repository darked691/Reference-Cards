<html><head><title>Birthdays Login</title>
<style type="text/css">
form{ font-family: Arial ,sans-serif;font-style : normal ;font-size : 9pt; font-weight :normal}
</style>
</head>
<body>
<div align="center">
<table width="350" cellpadding="10" cellspacing="0" border="2">
<tr align="center" valign="top">
<td align="left" colspan="1" rowspan="1"  bgcolor="#64B1FF">
<form method="POST" action="birthdays_dbase_interface.php">
<?php
print "Enter Username: <input type=text name=username size=20><br>\n";
print "Enter Password:  <input type=password name=password size=20><br>\n";
print "<br>\n";
print "<input type=submit value=Submit><input type=reset>\n";
?>
</form>
</td></tr></table>
</div>
</body>
</html>
